#!/usr/bin/python
print('Escape sequences')
print('\\a      Bell (alert)')
print('\\b      Backspace')
print('\\n      New line')
print('\\t      Horizontal tab')
print('\\\      Backslash \\')
print('\\\"     Double quotation mark \"')
print('\\\"     Single quotation mark \"')
