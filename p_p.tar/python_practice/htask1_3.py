x = input("enter x = ")
y = input("enter Y = ")
x = int(x)
y = int(y)
#вывести x и y
print('x = ', x, 'y = ', y)
#вывести сумму
print('x + y = ',x + y)
#целочисленное деление
if y!=0:
    print('x // y = ',x // y)
else:
    print("Divisinon by zero")
#остаток
print('x % y = ',x % y)
#степень
print('x * y =', x * y)


