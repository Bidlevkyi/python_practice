#!/urs/bin/python3
n = int(input("Enter quantity of children: "))
k = int(input("Enter quantity of apples: "))
if n > k:
    print("few apples")
else:
    r = k // n
    o = k - ( r * n)
    print("apples hor child: ", r)
    print("apples in basket", o)



