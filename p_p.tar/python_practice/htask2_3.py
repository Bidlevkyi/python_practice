a = int(input('Enter quantity of students in class a: '))
b = int(input('Enter quantity of students in class b: '))
c = int(input('Enter quantity of students in class c: '))
d = (a + b + c) % 2
if d == 0:
    print('For all students need tables: ', (a + b + c) / 2)
else:
    print('For all students need tables: ', ((a + b + c) // 2) + 1)
