#!/usr/bin/python
print('proverka')
